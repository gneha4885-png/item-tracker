import { useState } from 'react';
import axios from 'axios';

const API = 'http://localhost:8000';

function LogItemPage() {
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState('');
  const [lastSaved, setLastSaved] = useState(null);
  const email = localStorage.getItem('email') || 'User';
  const userId = localStorage.getItem('user_id') || 'neha123';

  function showToast(msg) { setToast(msg); setTimeout(() => setToast(''), 3000); }

  async function handleSave() {
    if (!text.trim() || text.length < 5) { showToast('Please describe where you kept the item!'); return; }
    setLoading(true);
    try {
      const response = await axios.post(API + '/log-item', { text, user_id: userId });
      setLastSaved(response.data);
      showToast('Saved successfully!');
      setText('');
    } catch (err) {
      showToast(err.response?.data?.detail || 'Cannot connect to server');
    }
    setLoading(false);
  }

  let recognition;
  function handleVoice() {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) { showToast('Voice not supported — use Chrome'); return; }
    recognition = new SR();
    recognition.lang = 'en-IN';
    recognition.onresult = e => setText(e.results[0][0].transcript);
    recognition.start();
    showToast('Listening...');
  }

  const suggestions = [
    { icon: '💳', text: 'I kept my Aadhaar card in the top drawer of my desk' },
    { icon: '🔑', text: 'Car keys are on the hook near the main door' },
    { icon: '💊', text: 'Medicines are in the kitchen cabinet top shelf' },
    { icon: '📘', text: 'Passport is in the blue folder in the cupboard' },
  ];

  return (
    <div className="app-container" style={{ background: '#0a0a0a' }}>

      {/* Header */}
      <div style={{
        padding: '56px 20px 20px',
        background: 'linear-gradient(180deg, rgba(201,168,76,0.06) 0%, transparent 100%)',
        borderBottom: '1px solid rgba(255,255,255,0.04)'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '4px' }}>
          <div>
            <p style={{ fontSize: '13px', color: '#555', marginBottom: '2px' }}>Good day 👋</p>
            <h1 style={{ fontSize: '22px', fontWeight: '700', color: '#fff', letterSpacing: '-0.3px' }}>
              {email.split('@')[0]}
            </h1>
          </div>
          <div style={{
            width: '40px', height: '40px',
            background: 'linear-gradient(135deg, #c9a84c, #e8c96d)',
            borderRadius: '12px', display: 'flex', alignItems: 'center',
            justifyContent: 'center', fontSize: '18px',
            boxShadow: '0 4px 15px rgba(201,168,76,0.2)'
          }}>📍</div>
        </div>
      </div>

      <div style={{ padding: '20px' }}>

        {/* Last saved banner */}
        {lastSaved && (
          <div className="animate-up" style={{
            background: 'rgba(0,196,140,0.08)', border: '1px solid rgba(0,196,140,0.15)',
            borderRadius: '14px', padding: '14px 16px', marginBottom: '16px',
            display: 'flex', alignItems: 'center', gap: '12px'
          }}>
            <span style={{ fontSize: '20px' }}>✅</span>
            <div>
              <p style={{ fontSize: '13px', color: '#00c48c', fontWeight: '600' }}>Just saved!</p>
              <p style={{ fontSize: '12px', color: '#555', marginTop: '2px' }}>
                {lastSaved.item_name} → {lastSaved.location}
              </p>
            </div>
          </div>
        )}

        {/* Input card */}
        <div className="card animate-up">
          <div className="label">Where did you keep it?</div>
          <div style={{ position: 'relative' }}>
            <textarea className="input-dark"
              value={text} onChange={e => setText(e.target.value)}
              placeholder="e.g. I kept my passport in the blue drawer in the bedroom..."
              style={{ height: '110px', resize: 'none', paddingRight: '50px', borderRadius: '12px' }}
            />
            <button onClick={handleVoice} style={{
              position: 'absolute', bottom: '10px', right: '10px',
              width: '34px', height: '34px',
              background: 'rgba(201,168,76,0.15)', border: '1px solid rgba(201,168,76,0.25)',
              borderRadius: '10px', cursor: 'pointer', fontSize: '16px',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              transition: 'all 0.2s'
            }}>🎤</button>
          </div>

          {/* Char count */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '8px', marginBottom: '16px' }}>
            <span style={{ fontSize: '11px', color: '#333' }}>{text.length} / 500</span>
            {text && <button onClick={() => setText('')} style={{ background: 'none', border: 'none', color: '#555', fontSize: '12px', cursor: 'pointer' }}>Clear</button>}
          </div>

          <button className="btn-gold" onClick={handleSave} disabled={loading}>
            {loading ? '✨ Saving with AI...' : 'Save Location'}
          </button>
        </div>

        {/* Suggestions */}
        <div className="card">
          <div className="label">Quick examples</div>
          {suggestions.map((s, i) => (
            <div key={i} onClick={() => setText(s.text)} style={{
              display: 'flex', alignItems: 'center', gap: '12px',
              padding: '12px', borderRadius: '10px', cursor: 'pointer',
              marginBottom: i < suggestions.length - 1 ? '6px' : '0',
              border: '1px solid rgba(255,255,255,0.04)',
              transition: 'all 0.15s', background: '#1a1a1a'
            }}
              onMouseEnter={e => e.currentTarget.style.borderColor = 'rgba(201,168,76,0.25)'}
              onMouseLeave={e => e.currentTarget.style.borderColor = 'rgba(255,255,255,0.04)'}
            >
              <span style={{
                width: '32px', height: '32px', background: '#222',
                borderRadius: '8px', display: 'flex', alignItems: 'center',
                justifyContent: 'center', fontSize: '16px', flexShrink: 0
              }}>{s.icon}</span>
              <span style={{ fontSize: '13px', color: '#888', lineHeight: '1.4' }}>{s.text}</span>
            </div>
          ))}
        </div>

      </div>

      {/* Logout */}
      <button onClick={() => { localStorage.clear(); window.location.href = '/'; }}
        style={{
          position: 'fixed', top: '16px', right: '16px',
          background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)',
          color: '#555', padding: '6px 14px', borderRadius: '20px',
          fontSize: '12px', cursor: 'pointer', zIndex: 999
        }}>Logout</button>

      <div className={`toast ${toast ? 'show' : ''}`}>{toast}</div>
    </div>
  );
}

export default LogItemPage;
