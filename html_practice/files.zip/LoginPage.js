import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const API = 'http://localhost:8000';

function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLogin, setIsLogin] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  async function handleSubmit() {
    if (!email || !password) { setError('Please fill all fields'); return; }
    setLoading(true); setError('');
    try {
      const endpoint = isLogin ? '/login' : '/register';
      const response = await axios.post(API + endpoint, { email, password });
      localStorage.setItem('token', response.data.token);
      localStorage.setItem('user_id', response.data.user_id);
      localStorage.setItem('email', response.data.email);
      navigate('/log');
    } catch (err) {
      setError(err.response?.data?.detail || 'Something went wrong');
    }
    setLoading(false);
  }

  return (
    <div style={{
      minHeight: '100vh', background: '#0a0a0a',
      display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center',
      padding: '24px 20px', maxWidth: '390px', margin: '0 auto'
    }}>

      {/* Top decoration */}
      <div style={{
        position: 'absolute', top: 0, left: 0, right: 0, height: '300px',
        background: 'radial-gradient(ellipse at 50% 0%, rgba(201,168,76,0.12) 0%, transparent 70%)',
        pointerEvents: 'none'
      }} />

      {/* Logo */}
      <div className="animate-up" style={{ textAlign: 'center', marginBottom: '48px' }}>
        <div style={{
          width: '72px', height: '72px',
          background: 'linear-gradient(135deg, #c9a84c, #e8c96d)',
          borderRadius: '22px', display: 'flex',
          alignItems: 'center', justifyContent: 'center',
          fontSize: '32px', margin: '0 auto 16px',
          boxShadow: '0 0 40px rgba(201,168,76,0.25), 0 8px 24px rgba(0,0,0,0.4)'
        }}>📍</div>
        <h1 style={{ fontSize: '28px', fontWeight: '700', color: '#fff', letterSpacing: '-0.5px' }}>
          ItemTracker
        </h1>
        <p style={{ color: '#555', fontSize: '14px', marginTop: '6px' }}>
          Your AI-powered memory assistant
        </p>
      </div>

      {/* Form card */}
      <div className="animate-up" style={{
        width: '100%', background: '#111111',
        borderRadius: '20px', border: '1px solid rgba(255,255,255,0.06)',
        padding: '28px 24px',
        boxShadow: '0 20px 60px rgba(0,0,0,0.5)'
      }}>
        {/* Toggle */}
        <div style={{
          display: 'flex', background: '#1a1a1a',
          borderRadius: '12px', padding: '4px', marginBottom: '24px'
        }}>
          {['Login', 'Register'].map((tab, i) => (
            <button key={tab} onClick={() => { setIsLogin(i === 0); setError(''); }}
              style={{
                flex: 1, padding: '10px',
                background: (isLogin ? i === 0 : i === 1) ? '#222' : 'transparent',
                border: (isLogin ? i === 0 : i === 1) ? '1px solid rgba(255,255,255,0.08)' : 'none',
                borderRadius: '10px', color: (isLogin ? i === 0 : i === 1) ? '#fff' : '#555',
                fontSize: '14px', fontWeight: '500', cursor: 'pointer', transition: 'all 0.2s'
              }}
            >{tab}</button>
          ))}
        </div>

        <input className="input-dark" type="email" placeholder="Email address"
          value={email} onChange={e => setEmail(e.target.value)}
          style={{ marginBottom: '12px' }} />

        <input className="input-dark" type="password" placeholder="Password (min 6 chars)"
          value={password} onChange={e => setPassword(e.target.value)}
          style={{ marginBottom: '20px' }}
          onKeyDown={e => e.key === 'Enter' && handleSubmit()} />

        {error && (
          <div style={{
            background: 'rgba(255,71,87,0.1)', border: '1px solid rgba(255,71,87,0.2)',
            borderRadius: '10px', padding: '10px 14px',
            color: '#ff4757', fontSize: '13px', marginBottom: '16px'
          }}>{error}</div>
        )}

        <button className="btn-gold" onClick={handleSubmit} disabled={loading}>
          {loading ? 'Please wait...' : (isLogin ? 'Login' : 'Create Account')}
        </button>
      </div>

      {/* Premium badge */}
      <div className="animate-up" style={{ marginTop: '32px', textAlign: 'center' }}>
        <span style={{
          fontSize: '11px', color: '#333', letterSpacing: '2px', textTransform: 'uppercase'
        }}>Powered by Claude AI</span>
      </div>
    </div>
  );
}

export default LoginPage;
