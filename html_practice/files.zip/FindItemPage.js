import { useState } from 'react';
import axios from 'axios';

const API = 'http://localhost:8000';

function FindItemPage() {
  const [query, setQuery] = useState('');
  const [answer, setAnswer] = useState('');
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState('');
  const [history, setHistory] = useState([]);
  const userId = localStorage.getItem('user_id') || 'neha123';

  function showToast(msg) { setToast(msg); setTimeout(() => setToast(''), 3000); }

  async function handleFind() {
    if (!query.trim()) return;
    setLoading(true);
    try {
      const response = await axios.get(API + '/find-item', { params: { query, user_id: userId } });
      setAnswer(response.data.answer);
      setHistory(prev => [{ query, answer: response.data.answer }, ...prev.slice(0, 4)]);
    } catch (err) {
      showToast('Cannot connect to server');
    }
    setLoading(false);
  }

  const quickSearches = ['Where are my keys?', 'Where is my passport?', 'Where are my glasses?', 'Where are my medicines?'];

  return (
    <div className="app-container" style={{ background: '#0a0a0a' }}>

      {/* Header */}
      <div style={{
        padding: '56px 20px 20px',
        background: 'linear-gradient(180deg, rgba(0,212,255,0.04) 0%, transparent 100%)',
        borderBottom: '1px solid rgba(255,255,255,0.04)'
      }}>
        <h1 style={{ fontSize: '22px', fontWeight: '700', color: '#fff', letterSpacing: '-0.3px' }}>Find Item</h1>
        <p style={{ fontSize: '13px', color: '#555', marginTop: '4px' }}>Ask AI where you kept something</p>
      </div>

      <div style={{ padding: '20px' }}>

        {/* Search box */}
        <div style={{ position: 'relative', marginBottom: '16px' }}>
          <input className="input-dark"
            value={query}
            onChange={e => setQuery(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleFind()}
            placeholder="Where are my car keys?"
            style={{ paddingRight: '52px', borderRadius: '14px' }}
          />
          <button onClick={handleFind} style={{
            position: 'absolute', right: '8px', top: '50%', transform: 'translateY(-50%)',
            width: '36px', height: '36px',
            background: 'linear-gradient(135deg, #c9a84c, #e8c96d)',
            border: 'none', borderRadius: '10px', cursor: 'pointer',
            fontSize: '16px', display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: '0 4px 15px rgba(201,168,76,0.25)'
          }}>🔍</button>
        </div>

        {/* Quick searches */}
        <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', marginBottom: '20px' }}>
          {quickSearches.map((q, i) => (
            <button key={i} onClick={() => { setQuery(q); }}
              style={{
                padding: '7px 14px', background: '#1a1a1a',
                border: '1px solid rgba(255,255,255,0.06)',
                borderRadius: '20px', color: '#666', fontSize: '12px',
                cursor: 'pointer', transition: 'all 0.15s',
                fontFamily: 'Inter, sans-serif'
              }}
              onMouseEnter={e => { e.currentTarget.style.borderColor = 'rgba(201,168,76,0.3)'; e.currentTarget.style.color = '#c9a84c'; }}
              onMouseLeave={e => { e.currentTarget.style.borderColor = 'rgba(255,255,255,0.06)'; e.currentTarget.style.color = '#666'; }}
            >{q}</button>
          ))}
        </div>

        {/* Loading */}
        {loading && (
          <div className="card animate-in" style={{ textAlign: 'center', padding: '32px' }}>
            <div style={{ fontSize: '32px', marginBottom: '12px' }}>🤖</div>
            <p style={{ color: '#555', fontSize: '14px' }}>AI is searching your items...</p>
            <div style={{
              width: '120px', height: '3px', background: '#1a1a1a',
              borderRadius: '2px', margin: '16px auto 0', overflow: 'hidden'
            }}>
              <div style={{
                height: '100%', width: '40%',
                background: 'linear-gradient(90deg, #c9a84c, #e8c96d)',
                borderRadius: '2px', animation: 'slide 1s ease-in-out infinite'
              }} />
            </div>
          </div>
        )}

        {/* Answer */}
        {answer && !loading && (
          <div className="card animate-up" style={{ border: '1px solid rgba(201,168,76,0.15)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '14px' }}>
              <div style={{
                width: '36px', height: '36px',
                background: 'rgba(201,168,76,0.1)',
                borderRadius: '10px', display: 'flex', alignItems: 'center',
                justifyContent: 'center', fontSize: '18px'
              }}>🤖</div>
              <div>
                <p style={{ fontSize: '12px', color: '#c9a84c', fontWeight: '600', textTransform: 'uppercase', letterSpacing: '0.8px' }}>AI Found It</p>
                <p style={{ fontSize: '11px', color: '#333', marginTop: '1px' }}>Powered by Claude</p>
              </div>
            </div>
            <div style={{ height: '1px', background: 'rgba(255,255,255,0.04)', marginBottom: '14px' }} />
            <p style={{ fontSize: '15px', lineHeight: '1.7', color: '#ddd' }}>{answer}</p>
            <button onClick={() => { setAnswer(''); setQuery(''); }}
              style={{
                marginTop: '16px', background: 'none', border: 'none',
                color: '#333', fontSize: '12px', cursor: 'pointer'
              }}>Clear result</button>
          </div>
        )}

        {/* Empty state */}
        {!answer && !loading && (
          <div style={{ textAlign: 'center', padding: '48px 20px' }}>
            <div style={{ fontSize: '48px', marginBottom: '16px', opacity: '0.3' }}>🔍</div>
            <p style={{ fontSize: '14px', color: '#333', lineHeight: '1.6' }}>
              Type a question above<br />or tap a quick search
            </p>
          </div>
        )}

        {/* Search history */}
        {history.length > 0 && (
          <div style={{ marginTop: '8px' }}>
            <p style={{ fontSize: '11px', color: '#333', textTransform: 'uppercase', letterSpacing: '1px', marginBottom: '12px' }}>Recent searches</p>
            {history.map((h, i) => (
              <div key={i} onClick={() => { setQuery(h.query); setAnswer(h.answer); }}
                style={{
                  display: 'flex', alignItems: 'center', gap: '12px',
                  padding: '12px', background: '#111', borderRadius: '12px',
                  marginBottom: '8px', cursor: 'pointer', border: '1px solid rgba(255,255,255,0.04)'
                }}>
                <span style={{ fontSize: '14px', color: '#333' }}>🕐</span>
                <span style={{ fontSize: '13px', color: '#555' }}>{h.query}</span>
              </div>
            ))}
          </div>
        )}

      </div>

      <div className={`toast ${toast ? 'show' : ''}`}>{toast}</div>
      <style>{`@keyframes slide { 0%{transform:translateX(-100%)} 100%{transform:translateX(350%)} }`}</style>
    </div>
  );
}

export default FindItemPage;
