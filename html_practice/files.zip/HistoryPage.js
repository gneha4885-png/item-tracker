import { useState, useEffect } from 'react';
import axios from 'axios';

const API = 'http://localhost:8000';

const EMOJI = { key:'🗝️',keys:'🗝️',passport:'📘',glasses:'👓',phone:'📱',medicine:'💊',medicines:'💊',wallet:'👛',laptop:'💻',charger:'🔌',book:'📚',watch:'⌚',card:'💳',aadhaar:'💳',clothes:'👗',shoes:'👟' };

function getEmoji(name) {
  if (!name) return '📦';
  const l = name.toLowerCase();
  for (const [k, v] of Object.entries(EMOJI)) if (l.includes(k)) return v;
  return '📦';
}

function timeAgo(ts) {
  if (!ts) return '';
  const d = Math.floor((Date.now() - new Date(ts).getTime()) / 1000);
  if (d < 60) return 'just now';
  if (d < 3600) return Math.floor(d/60) + 'm ago';
  if (d < 86400) return Math.floor(d/3600) + 'h ago';
  return Math.floor(d/86400) + 'd ago';
}

function cap(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : ''; }

function HistoryPage() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('All');
  const userId = localStorage.getItem('user_id') || 'neha123';

  useEffect(() => {
    async function fetchItems() {
      try {
        const response = await axios.get(API + '/my-items', { params: { user_id: userId } });
        setItems(response.data.items || []);
      } catch (err) { console.error('Error'); }
      setLoading(false);
    }
    fetchItems();
  }, []);

  const rooms = ['All', ...new Set(items.map(i => cap(i.room)).filter(r => r && r !== 'Unknown'))];
  const filtered = filter === 'All' ? items : items.filter(i => cap(i.room) === filter);

  return (
    <div className="app-container" style={{ background: '#0a0a0a' }}>

      {/* Header */}
      <div style={{
        padding: '56px 20px 20px',
        background: 'linear-gradient(180deg, rgba(201,168,76,0.04) 0%, transparent 100%)',
        borderBottom: '1px solid rgba(255,255,255,0.04)'
      }}>
        <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between' }}>
          <div>
            <h1 style={{ fontSize: '22px', fontWeight: '700', color: '#fff', letterSpacing: '-0.3px' }}>History</h1>
            <p style={{ fontSize: '13px', color: '#555', marginTop: '4px' }}>{items.length} items tracked</p>
          </div>
          <div style={{
            background: 'rgba(201,168,76,0.1)', border: '1px solid rgba(201,168,76,0.2)',
            borderRadius: '10px', padding: '8px 14px', textAlign: 'center'
          }}>
            <p style={{ fontSize: '20px', fontWeight: '700', color: '#c9a84c', lineHeight: '1' }}>{new Set(items.map(i => i.room).filter(r => r && r !== 'unknown')).size}</p>
            <p style={{ fontSize: '10px', color: '#555', marginTop: '2px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>Rooms</p>
          </div>
        </div>
      </div>

      <div style={{ padding: '20px' }}>

        {/* Room filter */}
        {rooms.length > 1 && (
          <div style={{ display: 'flex', gap: '8px', overflowX: 'auto', marginBottom: '20px', paddingBottom: '4px' }}>
            {rooms.map(room => (
              <button key={room} onClick={() => setFilter(room)}
                style={{
                  padding: '7px 16px', borderRadius: '20px', cursor: 'pointer',
                  background: filter === room ? 'linear-gradient(135deg, #c9a84c, #e8c96d)' : '#1a1a1a',
                  border: filter === room ? 'none' : '1px solid rgba(255,255,255,0.06)',
                  color: filter === room ? '#0a0a0a' : '#555',
                  fontSize: '12px', fontWeight: filter === room ? '600' : '400',
                  whiteSpace: 'nowrap', transition: 'all 0.2s',
                  fontFamily: 'Inter, sans-serif'
                }}
              >{room}</button>
            ))}
          </div>
        )}

        {/* Loading */}
        {loading && (
          <div style={{ textAlign: 'center', padding: '60px 20px' }}>
            <p style={{ color: '#333', fontSize: '14px' }}>Loading your items...</p>
          </div>
        )}

        {/* Empty */}
        {!loading && filtered.length === 0 && (
          <div style={{ textAlign: 'center', padding: '60px 20px' }}>
            <div style={{ fontSize: '48px', marginBottom: '16px', opacity: '0.2' }}>📭</div>
            <p style={{ color: '#333', fontSize: '14px', lineHeight: '1.6' }}>
              No items found.<br />Go to <strong style={{ color: '#c9a84c' }}>Log</strong> to start tracking!
            </p>
          </div>
        )}

        {/* Items */}
        {!loading && filtered.map((item, i) => (
          <div key={i} className="animate-up" style={{
            display: 'flex', alignItems: 'center', gap: '14px',
            padding: '14px 16px', background: '#111',
            borderRadius: '14px', marginBottom: '10px',
            border: '1px solid rgba(255,255,255,0.04)',
            cursor: 'pointer', transition: 'all 0.2s',
            animationDelay: `${i * 0.04}s`
          }}
            onMouseEnter={e => e.currentTarget.style.borderColor = 'rgba(201,168,76,0.2)'}
            onMouseLeave={e => e.currentTarget.style.borderColor = 'rgba(255,255,255,0.04)'}
          >
            {/* Icon */}
            <div style={{
              width: '46px', height: '46px', background: '#1a1a1a',
              borderRadius: '12px', display: 'flex', alignItems: 'center',
              justifyContent: 'center', fontSize: '22px', flexShrink: 0,
              border: '1px solid rgba(255,255,255,0.04)'
            }}>
              {getEmoji(item.item_name)}
            </div>

            {/* Info */}
            <div style={{ flex: 1, minWidth: 0 }}>
              <p style={{ fontSize: '15px', fontWeight: '600', color: '#fff', marginBottom: '3px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                {cap(item.item_name) || 'Item'}
              </p>
              <p style={{ fontSize: '12px', color: '#444', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                📍 {cap(item.location)} · {timeAgo(item.timestamp)}
              </p>
            </div>

            {/* Room badge */}
            <span style={{
              fontSize: '11px', padding: '4px 10px',
              background: 'rgba(201,168,76,0.08)',
              color: '#c9a84c', borderRadius: '20px',
              fontWeight: '500', flexShrink: 0,
              border: '1px solid rgba(201,168,76,0.15)'
            }}>
              {cap(item.room) || 'Unknown'}
            </span>
          </div>
        ))}

      </div>
    </div>
  );
}

export default HistoryPage;
