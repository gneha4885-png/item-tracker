import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const API = 'https://keeep-backend.onrender.com';

// ── shared design tokens ──────────────────────────────────────
const C = {
  green:      '#00c48c',
  greenDark:  '#009a6e',
  greenBg:    '#f0faf5',
  greenLight: '#e0f8ef',
  greenBorder:'#d6ede4',
  purple:     '#6c63ff',
  red:        '#ff6b6b',
  text:       '#0d4d32',
  textMid:    '#5a8070',
  textLight:  '#a0b8b0',
  white:      '#ffffff',
  inputBg:    '#f2fbf7',
};

const styles = {
  page: {
    minHeight: '100vh',
    background: C.greenBg,
    display: 'flex',
    flexDirection: 'column',
    fontFamily: "'Segoe UI', system-ui, sans-serif",
  },

  // ── WEB layout (≥768px) ──
  webWrap: {
    display: 'flex',
    minHeight: '100vh',
  },
  webLeft: {
    flex: 1,
    background: C.greenBg,
    padding: '48px 48px',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    position: 'relative',
    overflow: 'hidden',
  },
  webRight: {
    width: '380px',
    flexShrink: 0,
    background: 'rgba(255,255,255,0.95)',
    borderLeft: `1px solid ${C.greenBorder}`,
    padding: '40px 36px',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
  },

  // ── MOBILE layout (<768px) ──
  mobileHero: {
    background: C.greenBg,
    padding: '48px 24px 32px',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    position: 'relative',
    overflow: 'hidden',
  },
  mobileCard: {
    margin: '0 16px 24px',
    background: 'rgba(255,255,255,0.92)',
    borderRadius: '20px',
    padding: '24px 20px',
    boxShadow: '0 4px 24px rgba(0,80,50,0.08)',
    border: `1px solid ${C.greenBorder}`,
  },

  // ── shared form elements ──
  logoIcon: {
    width: '72px',
    height: '72px',
    background: C.white,
    borderRadius: '20px',
    border: `1px solid ${C.greenBorder}`,
    boxShadow: '0 4px 20px rgba(0,140,90,0.15)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  appName: {
    fontSize: '28px',
    fontWeight: 800,
    color: C.text,
    letterSpacing: '-0.4px',
    marginTop: '14px',
  },
  tagline: {
    fontSize: '13px',
    color: C.textMid,
    marginTop: '4px',
  },
  tabBar: {
    display: 'flex',
    borderBottom: `1.5px solid ${C.greenBorder}`,
    marginBottom: '18px',
  },
  tab: (active) => ({
    flex: 1,
    padding: '10px 0',
    fontSize: '14px',
    fontWeight: active ? 700 : 500,
    color: active ? C.text : C.textLight,
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    position: 'relative',
    fontFamily: "'Segoe UI', system-ui, sans-serif",
  }),
  tabUnderline: {
    position: 'absolute',
    bottom: '-1.5px',
    left: '15%',
    right: '15%',
    height: '2.5px',
    background: C.green,
    borderRadius: '2px',
  },
  inputWrap: { position: 'relative', marginBottom: '12px' },
  inputIcon: {
    position: 'absolute',
    left: '13px',
    top: '50%',
    transform: 'translateY(-50%)',
    fontSize: '16px',
    color: C.textLight,
    pointerEvents: 'none',
  },
  input: {
    width: '100%',
    padding: '13px 13px 13px 40px',
    background: C.inputBg,
    border: `1.5px solid ${C.greenBorder}`,
    borderRadius: '12px',
    fontSize: '14px',
    color: '#1a1a1a',
    outline: 'none',
    boxSizing: 'border-box',
    fontFamily: "'Segoe UI', system-ui, sans-serif",
    transition: 'border-color 0.2s',
  },
  row: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '18px',
  },
  remember: {
    display: 'flex',
    alignItems: 'center',
    gap: '6px',
    fontSize: '12px',
    color: C.textMid,
    cursor: 'pointer',
  },
  forgot: {
    fontSize: '12px',
    color: C.purple,
    fontWeight: 600,
    cursor: 'pointer',
    background: 'none',
    border: 'none',
    fontFamily: "'Segoe UI', system-ui, sans-serif",
  },
  btn: (loading) => ({
    position: 'relative',
    width: '100%',
    padding: '15px',
    background: loading ? C.greenDark : C.green,
    color: C.white,
    border: 'none',
    borderRadius: '14px',
    fontSize: '15px',
    fontWeight: 700,
    cursor: loading ? 'not-allowed' : 'pointer',
    overflow: 'hidden',
    fontFamily: "'Segoe UI', system-ui, sans-serif",
    transition: 'background 0.2s',
  }),
  divider: {
    display: 'flex',
    alignItems: 'center',
    gap: '10px',
    margin: '16px 0 14px',
  },
  divLine: { flex: 1, height: '0.5px', background: C.greenBorder },
  divTxt: { fontSize: '12px', color: C.textLight },
  socialRow: { display: 'flex', gap: '10px' },
  socialBtn: {
    flex: 1,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '7px',
    padding: '11px 8px',
    border: `1.5px solid ${C.greenBorder}`,
    borderRadius: '12px',
    background: C.white,
    fontSize: '13px',
    fontWeight: 500,
    color: '#444',
    cursor: 'pointer',
    fontFamily: "'Segoe UI', system-ui, sans-serif",
  },
  footer: { textAlign: 'center', marginTop: '16px', fontSize: '13px', color: C.textLight },
  footerLink: { color: C.purple, fontWeight: 600, cursor: 'pointer', background: 'none', border: 'none', fontFamily: "'Segoe UI', system-ui, sans-serif" },
  wakeToast: {
    background: '#fff8e1',
    border: '1px solid #ffe082',
    borderRadius: '10px',
    padding: '8px 12px',
    fontSize: '12px',
    color: '#b07800',
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    marginBottom: '14px',
  },
  errorBox: {
    background: '#fff5f5',
    border: '1px solid #ffcdd2',
    borderRadius: '10px',
    padding: '10px 14px',
    color: '#e53935',
    fontSize: '13px',
    marginBottom: '14px',
  },
  pill: (color, bg, border) => ({
    display: 'inline-flex',
    alignItems: 'center',
    gap: '5px',
    padding: '5px 12px',
    borderRadius: '20px',
    fontSize: '11px',
    fontWeight: 600,
    background: bg,
    border: `1px solid ${border}`,
    color: color,
  }),
};

// ── orb decoration ────────────────────────────────────────────
const Orb = ({ size, top, right, bottom, left, color, opacity, delay }) => (
  <div style={{
    position: 'absolute',
    width: size, height: size,
    borderRadius: '50%',
    background: color,
    opacity,
    top, right, bottom, left,
    animation: `orbDrift ${5 + delay}s ease-in-out ${delay}s infinite`,
    pointerEvents: 'none',
  }} />
);

// ── Google SVG ────────────────────────────────────────────────
const GoogleIcon = () => (
  <svg width="16" height="16" viewBox="0 0 18 18">
    <path fill="#4285F4" d="M17.64 9.2c0-.637-.057-1.251-.164-1.84H9v3.481h4.844c-.209 1.125-.843 2.078-1.796 2.717v2.258h2.908c1.702-1.567 2.684-3.875 2.684-6.615z"/>
    <path fill="#34A853" d="M9 18c2.43 0 4.467-.806 5.956-2.18l-2.908-2.259c-.806.54-1.837.86-3.048.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332A8.997 8.997 0 0 0 9 18z"/>
    <path fill="#FBBC05" d="M3.964 10.71A5.41 5.41 0 0 1 3.682 9c0-.593.102-1.17.282-1.71V4.958H.957A8.996 8.996 0 0 0 0 9c0 1.452.348 2.827.957 4.042l3.007-2.332z"/>
    <path fill="#EA4335" d="M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0A8.997 8.997 0 0 0 .957 4.958L3.964 7.29C4.672 5.163 6.656 3.58 9 3.58z"/>
  </svg>
);

// ── main component ────────────────────────────────────────────
function LoginPage() {
  const [email, setEmail]         = useState('');
  const [password, setPassword]   = useState('');
  const [isLogin, setIsLogin]     = useState(true);
  const [loading, setLoading]     = useState(false);
  const [error, setError]         = useState('');
  const [showWake, setShowWake]   = useState(false);
  const [isMobile, setIsMobile]   = useState(window.innerWidth < 768);
  const navigate = useNavigate();

  // ── server ping on load (Render cold start fix) ──
  useEffect(() => {
    axios.get(API + '/health').catch(() => {});
    const handleResize = () => setIsMobile(window.innerWidth < 768);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // ── if already logged in, skip to /log ──
  useEffect(() => {
    if (localStorage.getItem('token')) navigate('/log');
  }, [navigate]);

  async function handleSubmit() {
    if (!email || !password) { setError('Please fill all fields'); return; }
    setLoading(true); setError('');

    // show wake-up toast after 3 seconds
    const wakeTimer = setTimeout(() => setShowWake(true), 3000);

    try {
      const endpoint = isLogin ? '/login' : '/register';
      const res = await axios.post(API + endpoint, { email, password });
      clearTimeout(wakeTimer);
      setShowWake(false);

      // ── save session ──
      localStorage.setItem('token',   res.data.token);
      localStorage.setItem('user_id', res.data.user_id);
      localStorage.setItem('email',   res.data.email);
      localStorage.setItem('login_time', Date.now().toString());

      navigate('/log');
    } catch (err) {
      clearTimeout(wakeTimer);
      setShowWake(false);
      setError(err.response?.data?.detail || 'Something went wrong. Try again.');
    }
    setLoading(false);
  }

  // ── shared form ───────────────────────────────────────────
  const FormContent = () => (
    <>
      {/* wake toast */}
      {showWake && (
        <div style={styles.wakeToast}>
          <span>⏳</span>
          <span>Server warming up, please wait ~20 sec...</span>
        </div>
      )}

      {/* tabs */}
      <div style={styles.tabBar}>
        {['Login', 'Register'].map((t, i) => {
          const active = isLogin ? i === 0 : i === 1;
          return (
            <button key={t} style={styles.tab(active)}
              onClick={() => { setIsLogin(i === 0); setError(''); }}>
              {t}
              {active && <div style={styles.tabUnderline} />}
            </button>
          );
        })}
      </div>

      {/* inputs */}
      <div style={styles.inputWrap}>
        <span style={styles.inputIcon}>✉️</span>
        <input style={styles.input} type="email" placeholder="Email address"
          value={email} onChange={e => setEmail(e.target.value)} />
      </div>
      <div style={styles.inputWrap}>
        <span style={styles.inputIcon}>🔒</span>
        <input style={styles.input} type="password" placeholder="Password"
          value={password} onChange={e => setPassword(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && handleSubmit()} />
      </div>

      {isLogin && (
        <div style={styles.row}>
          <label style={styles.remember}>
            <input type="checkbox" defaultChecked style={{ accentColor: C.green }} />
            Keep me logged in
          </label>
          <button style={styles.forgot}>Forgot password?</button>
        </div>
      )}

      {error && <div style={styles.errorBox}>{error}</div>}

      <button style={styles.btn(loading)} onClick={handleSubmit} disabled={loading}>
        {loading ? '⏳ Please wait...' : (isLogin ? 'Login to Keeep' : 'Create Account')}
      </button>

      <div style={styles.divider}>
        <div style={styles.divLine} />
        <span style={styles.divTxt}>or continue with</span>
        <div style={styles.divLine} />
      </div>

      <div style={styles.socialRow}>
        <button style={styles.socialBtn}><GoogleIcon /> Google</button>
        <button style={styles.socialBtn}>🍎 Apple</button>
      </div>

      <div style={styles.footer}>
        {isLogin ? 'New to Keeep? ' : 'Have an account? '}
        <button style={styles.footerLink}
          onClick={() => { setIsLogin(!isLogin); setError(''); }}>
          {isLogin ? 'Create account →' : 'Login →'}
        </button>
      </div>
    </>
  );

  // ── WEB layout ────────────────────────────────────────────
  if (!isMobile) {
    return (
      <>
        <style>{`
          @keyframes orbDrift {
            0%,100% { transform: scale(1) translate(0,0); }
            50%      { transform: scale(1.1) translate(6px,-6px); }
          }
          @keyframes float {
            0%,100% { transform: translateY(0); }
            50%      { transform: translateY(-7px); }
          }
          input:focus { border-color: #00c48c !important; background: #fff !important; }
        `}</style>
        <div style={styles.webWrap}>
          {/* LEFT — branding */}
          <div style={styles.webLeft}>
            <Orb size="200px" bottom="-70px" left="-60px"  color="#00d09c" opacity={0.12} delay={0} />
            <Orb size="100px" top="20px"    right="20px"   color="#6c63ff" opacity={0.1}  delay={1} />
            <Orb size="70px"  top="60px"    left="30px"    color="#ff6b6b" opacity={0.08} delay={2} />

            {/* logo */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '36px', position: 'relative', zIndex: 1 }}>
              <div style={{ ...styles.logoIcon, animation: 'float 3.5s ease-in-out 1s infinite' }}>
                <svg width="38" height="38" viewBox="0 0 44 44" fill="none">
                  <circle cx="22" cy="18" r="12" fill="#00c48c"/>
                  <circle cx="22" cy="18" r="6" fill="#fff"/>
                  <rect x="20.2" y="28" width="3.6" height="10" rx="1.8" fill="#00c48c"/>
                </svg>
              </div>
              <span style={{ fontSize: '26px', fontWeight: 800, color: C.text, letterSpacing: '-0.4px' }}>
                K<span style={{ color: C.green }}>e</span><span style={{ color: C.purple }}>e</span><span style={{ color: C.red }}>p</span>
              </span>
            </div>

            <h1 style={{ fontSize: '34px', fontWeight: 800, color: '#0d3d28', lineHeight: 1.2, marginBottom: '12px', position: 'relative', zIndex: 1 }}>
              Never forget<br /><span style={{ color: C.green }}>where you kept</span><br />things again
            </h1>
            <p style={{ fontSize: '14px', color: C.textMid, lineHeight: 1.7, marginBottom: '32px', position: 'relative', zIndex: 1 }}>
              AI-powered item tracker.<br />Log with voice or text. Find in seconds.
            </p>

            {/* feature pills */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '14px', position: 'relative', zIndex: 1 }}>
              {[
                { icon: '⚡', text: 'Find any item instantly with Claude AI', bg: '#e0f8ef', border: '#a8eddc', color: '#007a5a' },
                { icon: '🎤', text: 'Log by voice — Hindi & English supported', bg: '#f0eefe', border: '#c8c3f5', color: '#5048cc' },
                { icon: '👨‍👩‍👧', text: 'Share item locations with your family', bg: '#fff0f0', border: '#ffbdbd', color: '#c04040' },
              ].map((f, i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                  <div style={{ width: '38px', height: '38px', borderRadius: '10px', background: f.bg, border: `1px solid ${f.border}`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '18px', flexShrink: 0 }}>
                    {f.icon}
                  </div>
                  <span style={{ fontSize: '13px', color: '#4a7060', fontWeight: 500 }}>{f.text}</span>
                </div>
              ))}
            </div>
          </div>

          {/* RIGHT — form */}
          <div style={styles.webRight}>
            <div style={{ fontSize: '22px', fontWeight: 800, color: C.text, marginBottom: '4px' }}>Welcome back 👋</div>
            <div style={{ fontSize: '13px', color: C.textLight, marginBottom: '24px' }}>Sign in to your Keeep account</div>
            <FormContent />
          </div>
        </div>
      </>
    );
  }

  // ── MOBILE layout ─────────────────────────────────────────
  return (
    <>
      <style>{`
        @keyframes orbDrift {
          0%,100% { transform: scale(1) translate(0,0); }
          50%      { transform: scale(1.1) translate(5px,-5px); }
        }
        @keyframes float {
          0%,100% { transform: translateY(0); }
          50%      { transform: translateY(-6px); }
        }
        @keyframes pinDrop {
          0%   { opacity:0; transform: translateY(-28px) scale(.8); }
          60%  { transform: translateY(4px) scale(1.06); }
          100% { opacity:1; transform: translateY(0) scale(1); }
        }
        input:focus { border-color: #00c48c !important; background: #fff !important; }
      `}</style>
      <div style={styles.page}>
        {/* gradient strip */}
        <div style={{ height: '3px', background: 'linear-gradient(90deg,#00d09c,#6c63ff,#ff6b6b)' }} />

        {/* hero */}
        <div style={styles.mobileHero}>
          <Orb size="160px" top="-60px"   right="-50px" color="#00d09c" opacity={0.14} delay={0} />
          <Orb size="80px"  bottom="-20px" left="-20px" color="#6c63ff" opacity={0.11} delay={1} />

          <div style={{ ...styles.logoIcon, animation: 'pinDrop .75s cubic-bezier(.22,1,.36,1) .2s both, float 3.5s ease-in-out 1.2s infinite', position: 'relative', zIndex: 1 }}>
            <svg width="38" height="38" viewBox="0 0 44 44" fill="none">
              <circle cx="22" cy="18" r="12" fill="#00c48c"/>
              <circle cx="22" cy="18" r="6" fill="#fff"/>
              <rect x="20.2" y="28" width="3.6" height="10" rx="1.8" fill="#00c48c"/>
            </svg>
          </div>
          <div style={{ width: '48px', height: '6px', background: 'rgba(0,100,60,.1)', borderRadius: '50%', margin: '4px auto 0' }} />

          <div style={styles.appName}>
            K<span style={{ color: C.green }}>e</span><span style={{ color: C.purple }}>e</span><span style={{ color: C.red }}>p</span>
          </div>
          <div style={styles.tagline}>Never forget where you kept things</div>

          <div style={{ display: 'flex', gap: '7px', marginTop: '14px', flexWrap: 'wrap', justifyContent: 'center' }}>
            <span style={styles.pill('#007a5a', '#e0f8ef', 'rgba(0,208,156,.3)')}>⚡ AI powered</span>
            <span style={styles.pill('#5048cc', '#f0eefe', 'rgba(108,99,255,.3)')}>🎤 Voice</span>
            <span style={styles.pill('#c04040', '#fff0f0', 'rgba(255,107,107,.3)')}>🔒 Secure</span>
          </div>
        </div>

        {/* form card */}
        <div style={styles.mobileCard}>
          <FormContent />
        </div>

        <p style={{ textAlign: 'center', fontSize: '12px', color: C.textLight, paddingBottom: '24px' }}>
          Powered by Claude AI 🤖
        </p>
      </div>
    </>
  );
}

export default LoginPage;
