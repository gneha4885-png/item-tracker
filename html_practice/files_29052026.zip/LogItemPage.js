import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useSession, logout } from '../hooks/useSession';
import BottomNav from '../components/BottomNav';

const API = 'https://keeep-backend.onrender.com';

const C = {
  green:'#00c48c', greenDark:'#009a6e', greenBg:'#f0faf5',
  greenLight:'#e0f8ef', greenBorder:'#d6ede4',
  purple:'#6c63ff', red:'#ff6b6b',
  text:'#0d4d32', textMid:'#5a8070', textLight:'#a0b8b0',
  white:'#ffffff', inputBg:'#f2fbf7',
};

function LogItemPage() {
  const navigate              = useNavigate();
  const { token, email }      = useSession();           // ← session guard
  const [text, setText]       = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState('');
  const [error, setError]     = useState('');
  const [listening, setListening] = useState(false);
  const [recent, setRecent]   = useState([]);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);

  useEffect(() => {
    const h = () => setIsMobile(window.innerWidth < 768);
    window.addEventListener('resize', h);
    fetchRecent();
    return () => window.removeEventListener('resize', h);
  }, []);

  async function fetchRecent() {
    try {
      const userId = localStorage.getItem('user_id');
      const res = await axios.get(`${API}/my-items?user_id=${userId}`);
      setRecent((res.data.items || []).slice(0, 3));
    } catch (_) {}
  }

  async function handleSave() {
    if (!text.trim()) { setError('Please describe what you kept and where'); return; }
    setLoading(true); setError(''); setSuccess('');
    try {
      const userId = localStorage.getItem('user_id');
      await axios.post(API + '/log-item', { text, user_id: userId });
      setSuccess('✅ Item saved successfully!');
      setText('');
      fetchRecent();
      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      if (err.response?.status === 401) { logout(navigate); return; }
      setError(err.response?.data?.detail || 'Failed to save. Try again.');
    }
    setLoading(false);
  }

  function handleVoice() {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) { setError('Voice not supported in this browser'); return; }
    const rec = new SR();
    rec.lang = 'hi-IN';          // supports Hindi
    rec.interimResults = false;
    rec.onstart  = () => setListening(true);
    rec.onend    = () => setListening(false);
    rec.onresult = (e) => setText(e.results[0][0].transcript);
    rec.onerror  = () => { setListening(false); setError('Voice error. Try again.'); };
    rec.start();
  }

  const username = (email || '').split('@')[0] || 'there';

  // ── SIDEBAR (web) ─────────────────────────────────────────
  const Sidebar = () => (
    <div style={{ width: '200px', flexShrink: 0, background: C.white, borderRight: `1px solid ${C.greenBorder}`, padding: '20px 12px', display: 'flex', flexDirection: 'column' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '28px', padding: '0 8px' }}>
        <div style={{ width: '32px', height: '32px', background: C.greenBg, borderRadius: '9px', border: `1px solid ${C.greenBorder}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <svg width="18" height="18" viewBox="0 0 44 44" fill="none"><circle cx="22" cy="18" r="12" fill="#00c48c"/><circle cx="22" cy="18" r="6" fill="#fff"/><rect x="20.2" y="28" width="3.6" height="10" rx="1.8" fill="#00c48c"/></svg>
        </div>
        <span style={{ fontSize: '18px', fontWeight: 800, color: C.text }}>
          K<span style={{ color: C.green }}>e</span><span style={{ color: C.purple }}>e</span><span style={{ color: C.red }}>p</span>
        </span>
      </div>

      {[
        { icon: '➕', label: 'Log Item',  path: '/log',     active: true },
        { icon: '🔍', label: 'Find Item', path: '/find',    active: false },
        { icon: '📋', label: 'History',   path: '/history', active: false },
      ].map(item => (
        <div key={item.path}
          onClick={() => navigate(item.path)}
          style={{
            display: 'flex', alignItems: 'center', gap: '10px',
            padding: '10px 12px', borderRadius: '10px',
            background: item.active ? C.greenLight : 'transparent',
            border: item.active ? `1px solid ${C.greenBorder}` : '1px solid transparent',
            color: item.active ? C.text : C.textMid,
            fontWeight: item.active ? 700 : 500,
            fontSize: '13px', cursor: 'pointer', marginBottom: '2px',
          }}>
          <span>{item.icon}</span>{item.label}
        </div>
      ))}

      <div style={{ flex: 1 }} />

      <div style={{ padding: '0 8px' }}>
        <div style={{ height: '0.5px', background: C.greenBorder, margin: '12px 0' }} />
        <div style={{ fontSize: '12px', color: C.textLight, marginBottom: '10px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
          👤 {email}
        </div>
        <button onClick={() => logout(navigate)} style={{ width: '100%', padding: '9px', background: '#fff5f5', border: '1px solid #ffcdd2', borderRadius: '10px', color: '#e53935', fontSize: '12px', fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit' }}>
          🚪 Logout
        </button>
      </div>
    </div>
  );

  // ── MAIN CONTENT ──────────────────────────────────────────
  const MainContent = () => (
    <div style={{ flex: 1, padding: isMobile ? '16px' : '28px 32px', overflowY: 'auto' }}>
      {/* header */}
      <div style={{ marginBottom: '24px' }}>
        <h1 style={{ fontSize: isMobile ? '20px' : '24px', fontWeight: 800, color: C.text }}>
          Hey {username}! 👋
        </h1>
        <p style={{ fontSize: '13px', color: C.textMid, marginTop: '3px' }}>
          Where did you keep something?
        </p>
      </div>

      <div style={{ display: isMobile ? 'block' : 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
        {/* log card */}
        <div style={{ background: C.white, border: `1px solid ${C.greenBorder}`, borderRadius: '16px', padding: '20px', marginBottom: isMobile ? '16px' : 0 }}>
          <div style={{ fontSize: '13px', fontWeight: 700, color: C.textMid, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: '12px' }}>
            Describe it
          </div>
          <textarea
            value={text}
            onChange={e => setText(e.target.value)}
            placeholder="e.g. I kept my passport in the blue drawer in the bedroom..."
            style={{
              width: '100%', padding: '12px', background: C.inputBg,
              border: `1.5px solid ${C.greenBorder}`, borderRadius: '12px',
              fontSize: '14px', color: '#1a1a1a', resize: 'none',
              outline: 'none', height: '90px', boxSizing: 'border-box',
              fontFamily: 'inherit',
            }}
          />

          <button onClick={handleVoice} style={{
            width: '100%', padding: '11px', marginTop: '8px',
            background: listening ? '#eeecfe' : '#f0eefe',
            border: `1.5px solid ${listening ? C.purple : '#c8c3f5'}`,
            borderRadius: '12px', fontSize: '13px', fontWeight: 600,
            color: C.purple, display: 'flex', alignItems: 'center',
            justifyContent: 'center', gap: '6px', cursor: 'pointer', fontFamily: 'inherit',
          }}>
            {listening ? '🔴 Listening...' : '🎤 Tap to speak (Hindi / English)'}
          </button>

          {error  && <div style={{ background: '#fff5f5', border: '1px solid #ffcdd2', borderRadius: '10px', padding: '10px', color: '#e53935', fontSize: '12px', marginTop: '10px' }}>{error}</div>}
          {success && <div style={{ background: C.greenLight, border: `1px solid ${C.greenBorder}`, borderRadius: '10px', padding: '10px', color: C.text, fontSize: '12px', marginTop: '10px' }}>{success}</div>}

          <button onClick={handleSave} disabled={loading} style={{
            width: '100%', padding: '14px', marginTop: '12px',
            background: loading ? C.greenDark : C.green,
            color: C.white, border: 'none', borderRadius: '12px',
            fontSize: '14px', fontWeight: 700, cursor: loading ? 'not-allowed' : 'pointer',
            fontFamily: 'inherit',
          }}>
            {loading ? '⏳ Saving...' : '📍 Save to Keeep'}
          </button>
        </div>

        {/* recent card */}
        <div style={{ background: C.white, border: `1px solid ${C.greenBorder}`, borderRadius: '16px', padding: '20px' }}>
          <div style={{ fontSize: '13px', fontWeight: 700, color: C.textMid, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: '12px' }}>
            Recently logged
          </div>
          {recent.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '24px 0', color: C.textLight, fontSize: '13px' }}>
              No items yet. Log your first item! 👆
            </div>
          ) : recent.map((item, i) => (
            <div key={i} style={{
              display: 'flex', alignItems: 'flex-start', gap: '10px',
              padding: '10px', border: `1px solid ${C.greenBorder}`,
              borderRadius: '10px', marginBottom: '8px', background: C.greenBg,
            }}>
              <div style={{ width: '34px', height: '34px', borderRadius: '9px', background: C.greenLight, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '16px', flexShrink: 0 }}>
                📦
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: '13px', fontWeight: 700, color: C.text, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {item.item_name || item.text?.substring(0, 30) || 'Item'}
                </div>
                <div style={{ fontSize: '11px', color: C.textMid, marginTop: '2px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {item.location || item.text?.substring(0, 50)}
                </div>
                <div style={{ fontSize: '10px', color: C.textLight, marginTop: '2px' }}>
                  {item.timestamp ? new Date(item.timestamp).toLocaleDateString('en-IN') : 'Just now'}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  // ── RENDER ────────────────────────────────────────────────
  return (
    <>
      <style>{`
        textarea:focus { border-color: #00c48c !important; background: #fff !important; }
        button:active  { opacity: 0.9; }
      `}</style>
      <div style={{ minHeight: '100vh', background: C.greenBg, display: 'flex', flexDirection: 'column', fontFamily: "'Segoe UI', system-ui, sans-serif" }}>
        <div style={{ height: '3px', background: 'linear-gradient(90deg,#00d09c,#6c63ff,#ff6b6b)', flexShrink: 0 }} />

        {isMobile ? (
          <>
            {/* mobile top bar */}
            <div style={{ background: C.white, borderBottom: `1px solid ${C.greenBorder}`, padding: '12px 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <span style={{ fontSize: '18px', fontWeight: 800, color: C.text }}>
                K<span style={{ color: C.green }}>e</span><span style={{ color: C.purple }}>e</span><span style={{ color: C.red }}>p</span>
              </span>
              <button onClick={() => logout(navigate)} style={{ padding: '6px 12px', background: '#fff5f5', border: '1px solid #ffcdd2', borderRadius: '8px', color: '#e53935', fontSize: '12px', fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit' }}>
                Logout
              </button>
            </div>
            <MainContent />
            <BottomNav active="log" />
          </>
        ) : (
          <div style={{ display: 'flex', flex: 1 }}>
            <Sidebar />
            <MainContent />
          </div>
        )}
      </div>
    </>
  );
}

export default LogItemPage;
